1. Install npm & Node
2. Go in directory via terminal and run 'npm install'
2. If you are using Linux then run 'chmod +x run.sh'. After that To start run './run.sh'
4. If you are using Windows then run To start  'run.sh' OR Go to coffee dir like cd node_modules/.bin>coffee index.coffee.md  
