# Start the Event Socket server
echo "****** Starting *******"
./node_modules/.bin/coffee index.coffee.md
echo "****** Ready *******"
